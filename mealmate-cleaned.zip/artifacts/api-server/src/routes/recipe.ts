import { Router, type IRouter } from "express";
import {
  getAllRecipes,
  getRecipeById,
  createRecipe,
} from "../controllers/recipe";

const router: IRouter = Router();

router.get("/recipes", getAllRecipes);
router.get("/recipes/:id", getRecipeById);
router.post("/recipes", createRecipe);

export default router;
