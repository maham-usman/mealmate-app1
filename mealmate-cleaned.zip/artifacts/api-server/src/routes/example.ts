import { Router, type IRouter } from "express";
import { getAll, getById, create, update, remove } from "../controllers/example";

const router: IRouter = Router();

router.get("/examples", getAll);
router.get("/examples/:id", getById);
router.post("/examples", create);
router.put("/examples/:id", update);
router.delete("/examples/:id", remove);

export default router;
