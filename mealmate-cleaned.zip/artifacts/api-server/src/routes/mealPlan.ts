import { Router, type IRouter } from "express";
import { getMealPlans, addMeal, removeMeal } from "../controllers/mealPlan";

const router: IRouter = Router();

router.get("/users/:userId/meal-plans", getMealPlans);
router.post("/users/:userId/meal-plans", addMeal);
router.patch("/users/:userId/meal-plans/:planId/remove-meal", removeMeal);

export default router;
