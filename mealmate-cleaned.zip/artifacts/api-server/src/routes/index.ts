import { Router, type IRouter } from "express";
import healthRouter from "./health";
import exampleRouter from "./example";
import recipeRouter from "./recipe";
import favoriteRouter from "./favorite";
import mealPlanRouter from "./mealPlan";

const router: IRouter = Router();

router.use(healthRouter);
router.use(exampleRouter);
router.use(recipeRouter);
router.use(favoriteRouter);
router.use(mealPlanRouter);

export default router;
