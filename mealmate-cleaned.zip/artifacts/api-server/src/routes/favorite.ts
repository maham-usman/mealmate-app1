import { Router, type IRouter } from "express";
import {
  getFavorites,
  addFavorite,
  removeFavorite,
} from "../controllers/favorite";

const router: IRouter = Router({ mergeParams: true });

router.get("/users/:userId/favorites", getFavorites);
router.post("/users/:userId/favorites", addFavorite);
router.delete("/users/:userId/favorites/:recipeId", removeFavorite);

export default router;
