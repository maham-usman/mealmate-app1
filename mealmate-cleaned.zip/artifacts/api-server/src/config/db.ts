import mongoose from "mongoose";
import { logger } from "../lib/logger";
import config from "./index";

export async function connectDB(): Promise<void> {
  const { mongoUri } = config;

  if (!mongoUri) {
    logger.warn("MONGO_URI is not set — skipping MongoDB connection");
    return;
  }

  try {
    await mongoose.connect(mongoUri);
    logger.info("MongoDB connected");
  } catch (err) {
    logger.error({ err }, "MongoDB connection failed");
    process.exit(1);
  }
}

mongoose.connection.on("disconnected", () => {
  logger.warn("MongoDB disconnected");
});

mongoose.connection.on("error", (err) => {
  logger.error({ err }, "MongoDB connection error");
});

export default mongoose;
