import "dotenv/config";

const config = {
  port: Number(process.env["PORT"] ?? 5000),
  nodeEnv: process.env["NODE_ENV"] ?? "development",
  mongoUri: process.env["MONGO_URI"] ?? "",
  db: {
    url: process.env["DATABASE_URL"] ?? "",
  },
} as const;

export default config;
