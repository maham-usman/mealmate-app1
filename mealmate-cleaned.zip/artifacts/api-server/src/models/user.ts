import { Schema, model, type Document } from "mongoose";

export type DietaryPreference =
  | "omnivore"
  | "vegetarian"
  | "vegan"
  | "keto"
  | "paleo"
  | "gluten-free"
  | "dairy-free";

export type Goal =
  | "lose_weight"
  | "gain_muscle"
  | "maintain_weight"
  | "improve_endurance"
  | "eat_healthier";

export interface IUser extends Document {
  name: string;
  email: string;
  age: number;
  height: number;
  weight: number;
  dietaryPreference: DietaryPreference;
  goal: Goal;
  createdAt: Date;
  updatedAt: Date;
}

const userSchema = new Schema<IUser>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    age: {
      type: Number,
      required: true,
      min: 1,
      max: 120,
    },
    height: {
      type: Number,
      required: true,
      min: 0,
    },
    weight: {
      type: Number,
      required: true,
      min: 0,
    },
    dietaryPreference: {
      type: String,
      required: true,
      enum: [
        "omnivore",
        "vegetarian",
        "vegan",
        "keto",
        "paleo",
        "gluten-free",
        "dairy-free",
      ] satisfies DietaryPreference[],
      default: "omnivore",
    },
    goal: {
      type: String,
      required: true,
      enum: [
        "lose_weight",
        "gain_muscle",
        "maintain_weight",
        "improve_endurance",
        "eat_healthier",
      ] satisfies Goal[],
    },
  },
  {
    timestamps: true,
  },
);

const User = model<IUser>("User", userSchema);

export default User;
