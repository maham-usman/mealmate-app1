export interface Example {
  id: number;
  name: string;
  createdAt: Date;
}
