import { Schema, model, type Document, type Types } from "mongoose";

export type MealType = "breakfast" | "lunch" | "dinner" | "snack";

export interface IMealPlanEntry {
  recipeId: Types.ObjectId;
  mealType: MealType;
}

export interface IMealPlan extends Document {
  userId: Types.ObjectId;
  date: Date;
  meals: IMealPlanEntry[];
  createdAt: Date;
  updatedAt: Date;
}

const mealPlanEntrySchema = new Schema<IMealPlanEntry>(
  {
    recipeId: {
      type: Schema.Types.ObjectId,
      ref: "Recipe",
      required: true,
    },
    mealType: {
      type: String,
      required: true,
      enum: ["breakfast", "lunch", "dinner", "snack"] satisfies MealType[],
    },
  },
  { _id: false },
);

const mealPlanSchema = new Schema<IMealPlan>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    date: {
      type: Date,
      required: true,
    },
    meals: {
      type: [mealPlanEntrySchema],
      default: [],
    },
  },
  {
    timestamps: true,
  },
);

mealPlanSchema.index({ userId: 1, date: 1 }, { unique: true });

const MealPlan = model<IMealPlan>("MealPlan", mealPlanSchema);

export default MealPlan;
