import { Schema, model, type Document, type Types } from "mongoose";

export interface IFavorite extends Document {
  userId: Types.ObjectId;
  recipeId: Types.ObjectId;
  createdAt: Date;
}

const favoriteSchema = new Schema<IFavorite>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    recipeId: {
      type: Schema.Types.ObjectId,
      ref: "Recipe",
      required: true,
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
  },
);

favoriteSchema.index({ userId: 1, recipeId: 1 }, { unique: true });

const Favorite = model<IFavorite>("Favorite", favoriteSchema);

export default Favorite;
