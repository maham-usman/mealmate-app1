import app from "./app";
import config from "./config";
import { connectDB } from "./config/db";
import { logger } from "./lib/logger";

const { port } = config;

if (!port || Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${process.env["PORT"]}"`);
}

async function start(): Promise<void> {
  await connectDB();

  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }

    logger.info({ port, env: config.nodeEnv }, "Server listening");
  });
}

start();
