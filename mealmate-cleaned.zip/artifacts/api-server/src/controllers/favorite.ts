import type { Request, Response } from "express";
import Favorite from "../models/favorite";

export async function getFavorites(
  req: Request<{ userId: string }>,
  res: Response,
): Promise<void> {
  const favorites = await Favorite.find({ userId: req.params.userId })
    .populate("recipeId")
    .sort({ createdAt: -1 });

  res.json(favorites);
}

export async function addFavorite(
  req: Request<{ userId: string }>,
  res: Response,
): Promise<void> {
  const { recipeId } = req.body as { recipeId: string };

  if (!recipeId) {
    res.status(400).json({ error: "recipeId is required" });
    return;
  }

  const existing = await Favorite.findOne({
    userId: req.params.userId,
    recipeId,
  });

  if (existing) {
    res.status(409).json({ error: "Recipe is already in favorites" });
    return;
  }

  const favorite = await Favorite.create({
    userId: req.params.userId,
    recipeId,
  });

  res.status(201).json(favorite);
}

export async function removeFavorite(
  req: Request<{ userId: string; recipeId: string }>,
  res: Response,
): Promise<void> {
  const result = await Favorite.findOneAndDelete({
    userId: req.params.userId,
    recipeId: req.params.recipeId,
  });

  if (!result) {
    res.status(404).json({ error: "Favorite not found" });
    return;
  }

  res.status(204).send();
}
