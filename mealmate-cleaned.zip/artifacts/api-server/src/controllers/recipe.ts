import type { Request, Response } from "express";
import { Recipe } from "../models";

export async function getAllRecipes(
  _req: Request,
  res: Response,
): Promise<void> {
  const recipes = await Recipe.find().sort({ createdAt: -1 });
  res.json(recipes);
}

export async function getRecipeById(
  req: Request<{ id: string }>,
  res: Response,
): Promise<void> {
  const recipe = await Recipe.findById(req.params.id);

  if (!recipe) {
    res.status(404).json({ error: "Recipe not found" });
    return;
  }

  res.json(recipe);
}

export async function createRecipe(
  req: Request,
  res: Response,
): Promise<void> {
  const recipe = await Recipe.create(req.body);
  res.status(201).json(recipe);
}
