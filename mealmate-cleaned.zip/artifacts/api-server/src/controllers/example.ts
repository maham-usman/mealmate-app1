import type { Request, Response } from "express";

export function getAll(_req: Request, res: Response): void {
  res.json({ message: "getAll — not implemented" });
}

export function getById(_req: Request, res: Response): void {
  res.json({ message: "getById — not implemented" });
}

export function create(_req: Request, res: Response): void {
  res.status(201).json({ message: "create — not implemented" });
}

export function update(_req: Request, res: Response): void {
  res.json({ message: "update — not implemented" });
}

export function remove(_req: Request, res: Response): void {
  res.status(204).send();
}
