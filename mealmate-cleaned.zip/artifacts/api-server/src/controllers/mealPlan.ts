import type { Request, Response } from "express";
import MealPlan from "../models/mealPlan";

export async function getMealPlans(
  req: Request<{ userId: string }>,
  res: Response,
): Promise<void> {
  const { date } = req.query as { date?: string };

  const filter: Record<string, unknown> = { userId: req.params.userId };

  if (date) {
    const day = new Date(date);
    const next = new Date(day);
    next.setDate(next.getDate() + 1);
    filter["date"] = { $gte: day, $lt: next };
  }

  const plans = await MealPlan.find(filter)
    .populate("meals.recipeId")
    .sort({ date: 1 });

  res.json(plans);
}

export async function addMeal(
  req: Request<{ userId: string }>,
  res: Response,
): Promise<void> {
  const { date, recipeId, mealType } = req.body as {
    date: string;
    recipeId: string;
    mealType: string;
  };

  if (!date || !recipeId || !mealType) {
    res.status(400).json({ error: "date, recipeId, and mealType are required" });
    return;
  }

  const day = new Date(date);

  const plan = await MealPlan.findOneAndUpdate(
    { userId: req.params.userId, date: day },
    { $push: { meals: { recipeId, mealType } } },
    { new: true, upsert: true },
  ).populate("meals.recipeId");

  res.status(201).json(plan);
}

export async function removeMeal(
  req: Request<{ userId: string; planId: string }>,
  res: Response,
): Promise<void> {
  const { recipeId, mealType } = req.body as {
    recipeId: string;
    mealType: string;
  };

  if (!recipeId || !mealType) {
    res.status(400).json({ error: "recipeId and mealType are required" });
    return;
  }

  const plan = await MealPlan.findByIdAndUpdate(
    req.params.planId,
    { $pull: { meals: { recipeId, mealType } } },
    { new: true },
  ).populate("meals.recipeId");

  if (!plan) {
    res.status(404).json({ error: "Meal plan not found" });
    return;
  }

  res.json(plan);
}
