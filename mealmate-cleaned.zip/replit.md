# API Server

A Node.js + Express backend with a clean layered structure: config, models, controllers, and routes.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

```
artifacts/api-server/src/
├── config/         # App-wide config (port, env, db url)
│   └── index.ts
├── controllers/    # Route handler functions (no business logic yet)
│   ├── index.ts
│   └── example.ts
├── models/         # TypeScript interfaces / data shapes
│   ├── index.ts
│   └── example.ts
├── routes/         # Express routers — wire controllers to HTTP paths
│   ├── index.ts    # Main router (mounts all sub-routers)
│   ├── health.ts   # GET /api/healthz
│   └── example.ts  # CRUD stubs for /api/examples
├── lib/
│   └── logger.ts   # Pino logger singleton
├── app.ts          # Express app setup (middleware, router mount)
└── index.ts        # Entry point — reads config, starts server

lib/api-spec/openapi.yaml   — OpenAPI contract (source of truth)
lib/db/src/schema/          — Drizzle ORM schema
```

## Architecture decisions

- Config is centralised in `src/config/index.ts` — no scattered `process.env` reads in route/controller files.
- Controllers are plain functions (`Request, Response`) — no classes, easy to test.
- Routes are thin: they only import the relevant controller and mount it; zero logic.
- Models are TypeScript interfaces only for now — Drizzle schema is the persistence layer when the DB is wired up.
- All routes are prefixed with `/api` in `app.ts`; individual routers use relative paths.

## Product

Backend scaffold with config, models, controllers, and routes layers. Ready to have domain entities and business logic added.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Always import `config` instead of reading `process.env` directly in business code.
- Add new entity routers in `src/routes/index.ts` to make them active.
- Run `pnpm --filter @workspace/api-spec run codegen` after any OpenAPI spec change before touching generated files.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
